/**
 * Web Audio API synthesizer for ambient romantic music and celebratory sound effects.
 * 100% self-contained with zero external audio assets to guarantee zero latency and 0 broken links.
 */

class SoundController {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private isBgmPlaying: boolean = false;
  private bgmTimeoutId: number | null = null;
  private bgmGainNode: GainNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.isMuted && this.bgmGainNode && this.ctx) {
      this.bgmGainNode.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
    } else if (!this.isMuted && this.bgmGainNode && this.ctx && this.isBgmPlaying) {
      this.bgmGainNode.gain.setTargetAtTime(0.12, this.ctx.currentTime, 0.2);
    }
    return this.isMuted;
  }

  public isMusicActive(): boolean {
    return this.isBgmPlaying && !this.isMuted;
  }

  /**
   * Plays a gentle, romantic music-box melody reminiscent of starry night and celebration
   */
  public startBgm() {
    this.initContext();
    if (this.isBgmPlaying) return;
    this.isBgmPlaying = true;

    if (!this.ctx) return;

    this.bgmGainNode = this.ctx.createGain();
    this.bgmGainNode.gain.setValueAtTime(this.isMuted ? 0 : 0.12, this.ctx.currentTime);
    this.bgmGainNode.connect(this.ctx.destination);

    // Pentatonic romantic birthday chord loop (C4, E4, G4, B4, C5, D5, G5, etc.)
    const melodyNotes = [
      261.63, 329.63, 392.00, 523.25, // C - E - G - C
      440.00, 392.00, 329.63, 293.66, // A - G - E - D
      329.63, 392.00, 493.88, 523.25, // E - G - B - C
      587.33, 523.25, 392.00, 329.63, // D - C - G - E
    ];

    let noteIndex = 0;

    const playNextNote = () => {
      if (!this.isBgmPlaying || !this.ctx || !this.bgmGainNode) return;

      const freq = melodyNotes[noteIndex % melodyNotes.length];
      noteIndex++;

      const osc = this.ctx.createOscillator();
      const noteGain = this.ctx.createGain();

      // Soft celesta / music box tone: mix of sine and soft triangle
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      // Envelope: soft attack, sustained bell decay
      const now = this.ctx.currentTime;
      noteGain.gain.setValueAtTime(0.001, now);
      noteGain.gain.exponentialRampToValueAtTime(0.2, now + 0.04);
      noteGain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

      osc.connect(noteGain);
      noteGain.connect(this.bgmGainNode);

      osc.start(now);
      osc.stop(now + 1.3);

      // Add gentle harmonic overtone
      const overtone = this.ctx.createOscillator();
      const overtoneGain = this.ctx.createGain();
      overtone.type = 'sine';
      overtone.frequency.setValueAtTime(freq * 2, now);
      overtoneGain.gain.setValueAtTime(0.001, now);
      overtoneGain.gain.exponentialRampToValueAtTime(0.05, now + 0.03);
      overtoneGain.gain.exponentialRampToValueAtTime(0.001, now + 0.9);

      overtone.connect(overtoneGain);
      overtoneGain.connect(this.bgmGainNode);

      overtone.start(now);
      overtone.stop(now + 1.0);

      // Pace: every 550ms
      this.bgmTimeoutId = window.setTimeout(playNextNote, 550);
    };

    playNextNote();
  }

  public stopBgm() {
    this.isBgmPlaying = false;
    if (this.bgmTimeoutId) {
      clearTimeout(this.bgmTimeoutId);
      this.bgmTimeoutId = null;
    }
    if (this.bgmGainNode && this.ctx) {
      this.bgmGainNode.gain.setTargetAtTime(0, this.ctx.currentTime, 0.3);
    }
  }

  public toggleBgm(): boolean {
    if (this.isBgmPlaying) {
      this.stopBgm();
      return false;
    } else {
      this.startBgm();
      return true;
    }
  }

  /**
   * Sound effect for blowing out candles (whoosh air + mystical soft chime)
   */
  public playCandleBlow() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // Breath / white noise puff
    const bufferSize = this.ctx.sampleRate * 0.45;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.18));
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, now);
    filter.frequency.exponentialRampToValueAtTime(150, now + 0.4);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    noise.start(now);
  }

  /**
   * Confetti celebration burst sound
   */
  public playConfettiPop() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // Pop oscillator
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(400, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.12);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.16);

    // Chime sparkle arpeggio
    const sparkles = [523.25, 659.25, 783.99, 1046.50, 1318.51];
    sparkles.forEach((freq, idx) => {
      if (!this.ctx) return;
      const sOsc = this.ctx.createOscillator();
      const sGain = this.ctx.createGain();
      const time = now + 0.05 + idx * 0.04;

      sOsc.type = 'sine';
      sOsc.frequency.setValueAtTime(freq, time);

      sGain.gain.setValueAtTime(0.001, time);
      sGain.gain.exponentialRampToValueAtTime(0.12, time + 0.02);
      sGain.gain.exponentialRampToValueAtTime(0.001, time + 0.5);

      sOsc.connect(sGain);
      sGain.connect(this.ctx.destination);

      sOsc.start(time);
      sOsc.stop(time + 0.55);
    });
  }

  /**
   * Sound effect for breaking wax seal on letter
   */
  public playWaxSeal() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(70, now + 0.08);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.09);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.1);
  }

  /**
   * Sound effect for opening gift box
   */
  public playGiftOpen() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880, 1108.73];
    notes.forEach((freq, i) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const t = now + i * 0.05;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.exponentialRampToValueAtTime(0.15, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.6);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.65);
    });
  }

  /**
   * Gentle sparkler sizzling crackle
   */
  public playSparklerCrackle() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1200 + Math.random() * 800, now);

    gain.gain.setValueAtTime(0.04, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.04);
  }

  /**
   * Soft interactive click feedback
   */
  public playChime(pitch: number = 880) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(pitch, now);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.22);
  }
}

export const sound = new SoundController();
