import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  rotation: number;
  rotationSpeed: number;
  color: string;
  opacity: number;
  type: 'confetti' | 'heart' | 'star';
  wobble: number;
  wobbleSpeed: number;
  scaleX: number;
}

const LUXURY_PALETTE = [
  '#f43f5e', // rose 500
  '#fb7185', // rose 400
  '#fda4af', // rose 300
  '#ffe4e6', // rose 100
  '#fbcfe8', // pink 200
  '#f472b6', // pink 400
  '#fbbf24', // amber 400 (gold)
  '#fef08a', // yellow 200 (champagne)
  '#e2e8f0', // platinum white
];

// Helper to draw a heart path
function drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, color: string, opacity: number) {
  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.fillStyle = color;
  ctx.translate(x, y);

  const s = size / 16;
  ctx.beginPath();
  ctx.moveTo(0, s * -4);
  ctx.bezierCurveTo(s * -6, s * -12, s * -14, s * -4, s * -14, s * 4);
  ctx.bezierCurveTo(s * -14, s * 10, s * -4, s * 16, 0, s * 20);
  ctx.bezierCurveTo(s * 4, s * 16, s * 14, s * 10, s * 14, s * 4);
  ctx.bezierCurveTo(s * 14, s * -4, s * 6, s * -12, 0, s * -4);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// Global burst trigger
let burstTrigger: ((count?: number, originX?: number, originY?: number) => void) | null = null;
export function fireGlobalBurst(count = 60, originX?: number, originY?: number) {
  if (burstTrigger) {
    burstTrigger(count, originX, originY);
  }
}

export const BackgroundCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const particles: Particle[] = [];
    const maxParticles = Math.min(85, Math.floor(width / 14)); // adaptive for mobile vs desktop

    const createParticle = (customY?: number, isBurst = false): Particle => {
      const typeRand = Math.random();
      const type: 'confetti' | 'heart' | 'star' = typeRand < 0.38 ? 'heart' : typeRand < 0.78 ? 'confetti' : 'star';
      const color = LUXURY_PALETTE[Math.floor(Math.random() * LUXURY_PALETTE.length)];

      const speedY = isBurst
        ? (Math.random() - 0.7) * 7
        : type === 'heart'
        ? -(0.4 + Math.random() * 0.9) // hearts gently float UP
        : 0.8 + Math.random() * 1.6; // confetti drifts DOWN

      const speedX = isBurst ? (Math.random() - 0.5) * 8 : (Math.random() - 0.5) * 1.2;

      return {
        x: Math.random() * width,
        y: customY !== undefined ? customY : type === 'heart' ? height + 20 : -20,
        size: type === 'heart' ? 9 + Math.random() * 10 : 5 + Math.random() * 7,
        speedY,
        speedX,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.05,
        color,
        opacity: 0.3 + Math.random() * 0.5,
        type,
        wobble: Math.random() * Math.PI * 2,
        wobbleSpeed: 0.03 + Math.random() * 0.04,
        scaleX: 1,
      };
    };

    // Pre-populate particles across screen
    for (let i = 0; i < maxParticles; i++) {
      const p = createParticle(Math.random() * height);
      particles.push(p);
    }

    // Connect burst function
    burstTrigger = (count = 50, originX = width / 2, originY = height / 2) => {
      for (let i = 0; i < count; i++) {
        const p = createParticle(originY, true);
        p.x = originX;
        particles.push(p);
      }
    };

    let lastTime = performance.now();

    const render = (time: number) => {
      const delta = Math.min((time - lastTime) / 16.6, 2.5);
      lastTime = time;

      ctx.clearRect(0, 0, width, height);

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];

        p.wobble += p.wobbleSpeed * delta;
        p.scaleX = Math.cos(p.wobble);
        p.rotation += p.rotationSpeed * delta;
        p.x += (p.speedX + Math.sin(p.wobble) * 0.7) * delta;
        p.y += p.speedY * delta;

        // Render based on type
        if (p.type === 'heart') {
          drawHeart(ctx, p.x, p.y, p.size, p.color, p.opacity);
          // Hearts float upwards and reset at bottom
          if (p.y < -30) {
            if (particles.length > maxParticles) {
              particles.splice(i, 1);
              continue;
            } else {
              p.y = height + 20;
              p.x = Math.random() * width;
            }
          }
        } else if (p.type === 'confetti') {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.scale(p.scaleX, 1);
          ctx.globalAlpha = p.opacity;
          ctx.fillStyle = p.color;

          // Rectangular / foil confetti ribbon
          ctx.fillRect(-p.size / 2, -p.size, p.size, p.size * 1.8);
          ctx.restore();

          // Confetti falls down and resets at top
          if (p.y > height + 30) {
            if (particles.length > maxParticles) {
              particles.splice(i, 1);
              continue;
            } else {
              p.y = -20;
              p.x = Math.random() * width;
            }
          }
        } else {
          // Stardust / sparkle
          ctx.save();
          ctx.globalAlpha = p.opacity * (0.6 + 0.4 * Math.sin(p.wobble * 2));
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.45, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          if (p.y > height + 20) {
            p.y = -10;
            p.x = Math.random() * width;
          }
        }

        // Horizontal boundary loop
        if (p.x < -40) p.x = width + 40;
        if (p.x > width + 40) p.x = -40;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      burstTrigger = null;
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 0.85 }}
    />
  );
};
