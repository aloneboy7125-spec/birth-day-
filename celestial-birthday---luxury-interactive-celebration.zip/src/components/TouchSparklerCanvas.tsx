import React, { useRef, useEffect, useState } from 'react';
import { Sparkles, Heart, Flame, Zap } from 'lucide-react';
import { sound } from '../utils/audio';

interface SparklerParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
}

const SPARKLER_COLORS = ['#fffae6', '#ffd700', '#ff9e00', '#ff5400', '#ff0054', '#ffffff'];

export const TouchSparklerCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isInteracting = useRef(false);
  const particles = useRef<SparklerParticle[]>([]);
  const lastSoundTime = useRef(0);

  const [activeMode, setActiveMode] = useState<'freeform' | 'heart' | 'fountain'>('freeform');

  const addSparklerSparks = (x: number, y: number, count = 12) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.2 + Math.random() * 4.5;
      particles.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 0,
        maxLife: 20 + Math.random() * 30,
        size: 1.5 + Math.random() * 2.5,
        color: SPARKLER_COLORS[Math.floor(Math.random() * SPARKLER_COLORS.length)],
      });
    }

    const now = performance.now();
    if (now - lastSoundTime.current > 80) {
      sound.playSparklerCrackle();
      lastSoundTime.current = now;
    }
  };

  const spawnHeartBurst = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;

    sound.playConfettiPop();

    // Spawn heart parametric curve
    for (let t = 0; t < Math.PI * 2; t += 0.1) {
      const hx = 16 * Math.pow(Math.sin(t), 3);
      const hy = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
      
      for (let s = 0; s < 4; s++) {
        particles.current.push({
          x: cx + hx * 6,
          y: cy + hy * 6,
          vx: (hx * 0.15 + (Math.random() - 0.5) * 2),
          vy: (hy * 0.15 + (Math.random() - 0.5) * 2),
          life: 0,
          maxLife: 35 + Math.random() * 25,
          size: 2 + Math.random() * 2.5,
          color: '#fda4af',
        });
      }
    }
  };

  const spawnFountain = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const cx = canvas.width / 2;
    const cy = canvas.height - 30;

    sound.playChime(980);

    for (let i = 0; i < 90; i++) {
      const angle = -Math.PI / 2 + (Math.random() - 0.5) * 0.8;
      const speed = 4 + Math.random() * 7;
      particles.current.push({
        x: cx + (Math.random() - 0.5) * 15,
        y: cy,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 0,
        maxLife: 35 + Math.random() * 30,
        size: 2 + Math.random() * 2,
        color: SPARKLER_COLORS[Math.floor(Math.random() * SPARKLER_COLORS.length)],
      });
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
    };
    resize();
    window.addEventListener('resize', resize);

    const render = () => {
      // Trail effect with dark fade
      ctx.fillStyle = 'rgba(11, 5, 7, 0.25)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      ctx.globalCompositeOperation = 'lighter';

      for (let i = particles.current.length - 1; i >= 0; i--) {
        const p = particles.current[i];
        p.life++;

        // Physics
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.08; // subtle gravity
        p.vx *= 0.98;

        const progress = p.life / p.maxLife;
        if (progress >= 1) {
          particles.current.splice(i, 1);
          continue;
        }

        const alpha = 1 - progress;
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1 - progress * 0.5), 0, Math.PI * 2);
        ctx.fill();

        // Cross flare star on brightest sparks
        if (p.size > 2.5 && p.life % 2 === 0) {
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(p.x - 4, p.y);
          ctx.lineTo(p.x + 4, p.y);
          ctx.moveTo(p.x, p.y - 4);
          ctx.lineTo(p.x, p.y + 4);
          ctx.stroke();
        }
      }

      ctx.restore();
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animId);
    };
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    isInteracting.current = true;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    addSparklerSparks(x, y, 20);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isInteracting.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    addSparklerSparks(x, y, 6);
  };

  const handlePointerUp = () => {
    isInteracting.current = false;
  };

  return (
    <section className="relative py-12 px-4 max-w-xl mx-auto flex flex-col items-center">
      {/* Header */}
      <div className="text-center max-w-md mx-auto mb-6">
        <span className="text-xs uppercase tracking-[0.25em] text-rose-300/70 font-medium">
          Pure Magic
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-rose-100 mt-1 mb-2">
          Celestial Sparkler
        </h2>
        <p className="text-xs sm:text-sm text-rose-200/60">
          Touch or drag across the velvet canvas to paint real crackling sparklers
        </p>
      </div>

      {/* Interactive Sparkler Canvas */}
      <div className="relative w-full h-72 sm:h-80 rounded-2xl bg-[#0e0408] border border-rose-500/30 overflow-hidden shadow-[0_15px_45px_rgba(0,0,0,0.9)] select-none">
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          className="w-full h-full cursor-crosshair touch-none"
        />

        {/* Ambient watermark prompt */}
        <div className="absolute inset-x-0 bottom-3 text-center pointer-events-none">
          <span className="text-[11px] text-rose-300/40 tracking-widest uppercase">
            Drag finger to ignite golden sparks ✨
          </span>
        </div>
      </div>

      {/* Mode Controls */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
        <button
          onClick={spawnHeartBurst}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-200 text-xs font-medium hover:bg-rose-900/60 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
        >
          <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
          <span>Heart Sparkler</span>
        </button>

        <button
          onClick={spawnFountain}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-950/50 border border-amber-500/30 text-amber-200 text-xs font-medium hover:bg-amber-900/60 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
        >
          <Flame className="w-3.5 h-3.5 text-amber-400" />
          <span>Stardust Fountain</span>
        </button>
      </div>
    </section>
  );
};
