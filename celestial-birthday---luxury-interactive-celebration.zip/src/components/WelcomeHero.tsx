import React from 'react';
import { Sparkles, Music, VolumeX, ArrowDown, Heart } from 'lucide-react';
import { sound } from '../utils/audio';
import { fireGlobalBurst } from './BackgroundCanvas';

interface WelcomeHeroProps {
  recipientName: string;
  isMusicPlaying: boolean;
  onToggleMusic: () => void;
  onOpenPersonalize: () => void;
}

export const WelcomeHero: React.FC<WelcomeHeroProps> = ({
  recipientName,
  isMusicPlaying,
  onToggleMusic,
  onOpenPersonalize,
}) => {
  const handleHeroBurst = () => {
    sound.playConfettiPop();
    fireGlobalBurst(70, window.innerWidth / 2, window.innerHeight * 0.35);
  };

  const scrollToCake = () => {
    sound.playChime(660);
    const element = document.getElementById('cake-section');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[85vh] sm:min-h-[90vh] flex flex-col items-center justify-center text-center px-4 pt-16 pb-12 overflow-hidden">
      {/* Background radial luxury lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[340px] sm:w-[500px] h-[340px] sm:h-[500px] bg-gradient-to-tr from-rose-600/15 via-pink-600/10 to-amber-400/10 rounded-full blur-3xl pointer-events-none" />

      {/* Editorial Chapter Tag */}
      <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-rose-950/60 border border-rose-400/30 text-rose-200/90 text-xs tracking-[0.2em] uppercase font-medium shadow-sm mb-5">
        <Heart className="w-3 h-3 text-rose-400 fill-rose-500 animate-pulse" />
        <span>A Celestial Milestone</span>
      </div>

      {/* Main Luxury Headline */}
      <div className="max-w-2xl mx-auto space-y-2">
        <span className="block text-xs sm:text-sm font-light uppercase tracking-[0.35em] text-rose-300/80">
          Celebrating The Wonder Of
        </span>
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif-luxury font-extrabold tracking-tight bg-gradient-to-r from-rose-100 via-pink-200 to-amber-200 bg-clip-text text-transparent drop-shadow-[0_4px_24px_rgba(244,63,94,0.35)] leading-[1.15]">
          Happy Birthday,
          <br />
          <span className="font-cursive-luxury italic text-rose-200 hover:text-amber-200 transition-colors cursor-pointer" onClick={onOpenPersonalize} title="Tap to change name">
            {recipientName}
          </span>
        </h1>
      </div>

      {/* Editorial Subtitle */}
      <p className="mt-5 max-w-md sm:max-w-lg text-sm sm:text-base font-light text-rose-200/80 leading-relaxed font-cursive-luxury text-lg sm:text-xl">
        On this day, the cosmos gave the earth someone truly extraordinary. May your year ahead be wrapped in starlight, quiet wonder, and deep, boundless happiness.
      </p>

      {/* Interactive Action Hub */}
      <div className="mt-8 flex flex-col sm:flex-row items-center gap-3.5 z-10">
        <button
          onClick={scrollToCake}
          className="min-h-[48px] px-8 py-3 rounded-2xl bg-gradient-to-r from-rose-500 via-pink-500 to-amber-400 text-stone-950 font-bold text-xs uppercase tracking-widest shadow-[0_0_25px_rgba(244,63,94,0.5)] hover:shadow-[0_0_35px_rgba(244,63,94,0.8)] active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-stone-950" />
          <span>Begin Experience</span>
        </button>

        <button
          onClick={onToggleMusic}
          className="min-h-[48px] px-5 py-3 rounded-2xl bg-rose-950/60 border border-rose-500/30 text-rose-200 hover:bg-rose-900/60 active:scale-95 transition-all flex items-center gap-2.5 text-xs font-medium tracking-wider cursor-pointer"
        >
          {isMusicPlaying ? (
            <>
              <Music className="w-4 h-4 text-rose-400 animate-bounce" />
              <span>Playing Serenade</span>
            </>
          ) : (
            <>
              <VolumeX className="w-4 h-4 text-rose-400/60" />
              <span>Play Birthday Melody</span>
            </>
          )}
        </button>
      </div>

      {/* Quick Tap Celebration trigger */}
      <div className="mt-6">
        <button
          onClick={handleHeroBurst}
          className="text-[11px] text-rose-300/60 hover:text-rose-200 uppercase tracking-widest flex items-center gap-1.5 transition-colors cursor-pointer py-1 px-3 rounded-full hover:bg-rose-950/40"
        >
          <span>Tap for a shower of hearts</span>
          <span className="text-rose-400">💖</span>
        </button>
      </div>

      {/* Scroll indicator */}
      <div className="mt-12 sm:mt-16 flex flex-col items-center gap-2 text-rose-400/50">
        <span className="text-[10px] tracking-widest uppercase">Scroll Down</span>
        <ArrowDown className="w-4 h-4 animate-bounce" />
      </div>
    </section>
  );
};
