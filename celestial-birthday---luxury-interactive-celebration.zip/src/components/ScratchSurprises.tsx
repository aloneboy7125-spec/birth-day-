import React, { useState } from 'react';
import { Sparkles, Eye, Heart, Compass, Star, Smile } from 'lucide-react';
import { sound } from '../utils/audio';
import { fireGlobalBurst } from './BackgroundCanvas';

interface SurpriseCard {
  id: string;
  category: string;
  icon: React.ReactNode;
  preview: string;
  hiddenMessage: string;
}

const SURPRISE_CARDS: SurpriseCard[] = [
  {
    id: '1',
    category: 'Daily Truth',
    icon: <Smile className="w-4 h-4 text-amber-300" />,
    preview: 'Tap to unveil a truth about your soul',
    hiddenMessage: 'You possess a calm, magnetic warmth. Simply standing near you makes people breathe a little easier.',
  },
  {
    id: '2',
    category: 'Infinite Hug Voucher',
    icon: <Heart className="w-4 h-4 text-rose-400" />,
    preview: 'Open when you need unconditional warmth',
    hiddenMessage: 'Redeemable anytime, anywhere: One tight, silent, comforting hug for as long as you need.',
  },
  {
    id: '3',
    category: 'Cosmic Horoscope',
    icon: <Star className="w-4 h-4 text-yellow-300" />,
    preview: 'Open for your personal birthday star alignment',
    hiddenMessage: 'The universe is shifting in your favor this year. What once felt out of reach is arriving softly at your doorstep.',
  },
  {
    id: '4',
    category: 'A Secret Reason',
    icon: <Compass className="w-4 h-4 text-emerald-400" />,
    preview: 'Open to find out why you are deeply loved',
    hiddenMessage: 'Because you have the courage to care deeply in a world that often pretends not to feel at all.',
  },
];

export const ScratchSurprises: React.FC = () => {
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});

  const handleReveal = (id: string) => {
    if (revealedIds[id]) return;
    sound.playConfettiPop();
    sound.playChime(880);
    fireGlobalBurst(25);
    setRevealedIds((prev) => ({ ...prev, [id]: true }));
  };

  const handleRevealAll = () => {
    sound.playConfettiPop();
    fireGlobalBurst(50);
    const all: Record<string, boolean> = {};
    SURPRISE_CARDS.forEach((c) => (all[c.id] = true));
    setRevealedIds(all);
  };

  return (
    <section className="relative py-12 px-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-md mx-auto mb-8">
        <span className="text-xs uppercase tracking-[0.25em] text-rose-300/70 font-medium">
          Golden Envelopes
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-rose-100 mt-1 mb-2">
          Affirmation Cards
        </h2>
        <p className="text-xs sm:text-sm text-rose-200/60">
          Tap each golden-foil card to scrape away the veil and reveal a heartfelt secret
        </p>
      </div>

      {/* Grid of Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {SURPRISE_CARDS.map((card) => {
          const isRevealed = !!revealedIds[card.id];

          return (
            <div
              key={card.id}
              onClick={() => handleReveal(card.id)}
              className={`relative cursor-pointer rounded-2xl p-5 border transition-all duration-300 select-none ${
                isRevealed
                  ? 'bg-gradient-to-b from-[#240a13] to-[#120409] border-rose-400/40 shadow-[0_8px_30px_rgba(244,63,94,0.2)]'
                  : 'bg-gradient-to-br from-[#1c0c05] via-[#221008] to-[#130602] border-amber-500/40 hover:border-amber-400 hover:shadow-[0_8px_30px_rgba(251,191,36,0.25)]'
              }`}
            >
              {/* Foil Shimmer Texture overlay for unrevealed */}
              {!isRevealed && (
                <div className="absolute inset-0 rounded-2xl bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-200/10 via-transparent to-transparent pointer-events-none" />
              )}

              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-black/40 border border-white/10 flex items-center justify-center">
                    {card.icon}
                  </div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-rose-200">
                    {card.category}
                  </span>
                </div>

                {!isRevealed ? (
                  <span className="text-[11px] font-mono text-amber-300/70 tracking-wider flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>LOCKED</span>
                  </span>
                ) : (
                  <span className="text-[11px] font-mono text-rose-400 tracking-wider flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    <span>REVEALED</span>
                  </span>
                )}
              </div>

              {/* Card Body */}
              <div className="min-h-[75px] flex items-center">
                {!isRevealed ? (
                  <div className="w-full text-center py-3 bg-black/30 rounded-xl border border-dashed border-amber-400/30 group-hover:border-amber-300">
                    <p className="text-xs text-amber-200/70 font-medium">
                      {card.preview}
                    </p>
                    <span className="text-[10px] text-amber-400/50 uppercase tracking-widest mt-1 block">
                      Tap to scratch foil
                    </span>
                  </div>
                ) : (
                  <div className="w-full animate-fade-in">
                    <p className="font-cursive-luxury italic text-stone-100 text-base leading-relaxed">
                      &quot;{card.hiddenMessage}&quot;
                    </p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 flex justify-center">
        <button
          onClick={handleRevealAll}
          className="min-h-[44px] px-5 py-2 rounded-xl bg-rose-950/40 border border-rose-500/20 text-rose-300/80 text-xs font-medium hover:bg-rose-900/40 active:scale-95 transition-all cursor-pointer flex items-center gap-2"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Reveal All Cards</span>
        </button>
      </div>
    </section>
  );
};
