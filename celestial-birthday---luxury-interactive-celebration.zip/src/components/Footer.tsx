import React from 'react';
import { Heart, Sparkles, RotateCcw } from 'lucide-react';
import { sound } from '../utils/audio';
import { fireGlobalBurst } from './BackgroundCanvas';

interface FooterProps {
  recipientName: string;
  onReplayLoading: () => void;
}

export const Footer: React.FC<FooterProps> = ({ recipientName, onReplayLoading }) => {
  const handleGrandFinale = () => {
    sound.playConfettiPop();
    fireGlobalBurst(120, window.innerWidth / 2, window.innerHeight * 0.5);
  };

  return (
    <footer className="relative pt-16 pb-24 md:pb-16 px-4 text-center border-t border-rose-500/15 bg-gradient-to-b from-transparent to-[#070204]">
      <div className="max-w-md mx-auto space-y-4">
        {/* Grand Finale Burst Button */}
        <div>
          <button
            onClick={handleGrandFinale}
            className="min-h-[44px] px-6 py-2.5 rounded-full bg-rose-950/60 border border-rose-400/40 text-rose-200 text-xs font-semibold uppercase tracking-widest hover:bg-rose-900/60 active:scale-95 transition-all inline-flex items-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(244,63,94,0.3)]"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Grand Finale Firework Shower</span>
          </button>
        </div>

        <p className="font-cursive-luxury italic text-xl text-rose-200/90 pt-3">
          &quot;May your dreams always burn brighter than your fears, {recipientName}.&quot;
        </p>

        <div className="flex items-center justify-center gap-2 text-xs text-rose-400/60 pt-2">
          <span>Crafted with devotion & stardust</span>
          <span>·</span>
          <span className="text-rose-300 font-medium">Aryan</span>
        </div>

        <div className="pt-3">
          <button
            onClick={onReplayLoading}
            className="text-[11px] text-rose-400/50 hover:text-rose-200 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Replay Initial Experience</span>
          </button>
        </div>
      </div>
    </footer>
  );
};
