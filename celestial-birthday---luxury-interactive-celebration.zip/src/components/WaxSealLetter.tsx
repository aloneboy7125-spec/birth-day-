import React, { useState } from 'react';
import { Mail, Edit3, Check, Heart, Feather } from 'lucide-react';
import { sound } from '../utils/audio';
import { fireGlobalBurst } from './BackgroundCanvas';

interface WaxSealLetterProps {
  recipientName: string;
}

const LETTER_PRESETS: Record<string, string> = {
  romantic: `My Dearest [Name],

From the moment you entered my world, everything took on a softer glow and a deeper melody. You have this rare, quiet magic—the kind that makes ordinary afternoons feel sacred and turns simple laughter into a sanctuary.

On this special birthday, I want you to remember just how deeply cherished you are. For every smile you've given without hesitation, for the warmth in your voice, and for the gentle light you carry wherever you go.

May this new year bring you everything your heart has dreamed of, wrapped in endless joy, peace, and love. 

Happy Birthday, my favorite person in the cosmos.`,
  bestie: `Happy Birthday to the most extraordinary [Name]!

Life would be so terribly mundane without your chaotic brilliance, your unmatched humor, and your loyal heart. Thank you for being the person who always gets my jokes before I even finish them and for being there through every single chapter.

May your day be overflowing with your favorite cake, non-stop laughter, and pure happiness. You deserve the absolute world!`,
  poetic: `To [Name], on your birthday:

If time is a river, then meeting you was finding the ocean. With every passing year, your grace deepens, your wisdom expands, and your spirit shines even brighter.

You are the poetry the world forgets to write and the warmth it desperately seeks. May today be only the first verse of your most enchanting year yet.`
};

export const WaxSealLetter: React.FC<WaxSealLetterProps> = ({ recipientName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState<'romantic' | 'bestie' | 'poetic'>('romantic');
  const [isEditing, setIsEditing] = useState(false);
  const [customText, setCustomText] = useState('');

  const currentText = (customText || LETTER_PRESETS[selectedTheme]).replace(/\[Name\]/g, recipientName);

  const handleOpenEnvelope = () => {
    if (isOpen) return;
    sound.playWaxSeal();
    sound.playChime(784);
    setIsOpen(true);
    setTimeout(() => {
      sound.playConfettiPop();
      fireGlobalBurst(35);
    }, 400);
  };

  return (
    <section className="relative py-12 px-4 flex flex-col items-center">
      {/* Header */}
      <div className="text-center max-w-md mx-auto mb-8">
        <span className="text-xs uppercase tracking-[0.25em] text-rose-300/70 font-medium">
          Confidential & Eternal
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-rose-100 mt-1 mb-2">
          The Sealed Letter
        </h2>
        <p className="text-xs sm:text-sm text-rose-200/60">
          A parchment letter sealed with rose wax, waiting for your touch to unfold
        </p>
      </div>

      <div className="w-full max-w-lg mx-auto">
        {!isOpen ? (
          /* Sealed Envelope View */
          <div
            onClick={handleOpenEnvelope}
            className="group cursor-pointer relative mx-auto w-full max-w-md aspect-[16/11] rounded-2xl bg-gradient-to-br from-[#240a13] via-[#1a060d] to-[#0f0307] border border-rose-500/30 p-6 shadow-[0_15px_40px_rgba(0,0,0,0.85)] flex flex-col items-center justify-center transition-all duration-300 hover:border-rose-400/60 hover:shadow-[0_15px_45px_rgba(244,63,94,0.25)] select-none"
          >
            {/* Envelope flap folds illusion */}
            <div className="absolute inset-x-0 top-0 h-1/2 border-b border-rose-500/20 bg-gradient-to-b from-rose-950/20 to-transparent pointer-events-none rounded-t-2xl" />
            <div className="absolute inset-y-0 left-0 w-1/3 border-r border-rose-500/10 pointer-events-none" />
            <div className="absolute inset-y-0 right-0 w-1/3 border-l border-rose-500/10 pointer-events-none" />

            {/* Recipient calligraphy tag */}
            <div className="text-center mb-6">
              <span className="text-[11px] uppercase tracking-[0.2em] text-rose-300/60">
                To My Beloved
              </span>
              <h3 className="text-xl sm:text-2xl font-cursive-luxury italic text-amber-200 font-bold mt-0.5">
                {recipientName}
              </h3>
            </div>

            {/* Wax Seal Medallion */}
            <div className="relative group-hover:scale-110 active:scale-95 transition-transform duration-200">
              {/* Outer seal glow */}
              <div className="absolute -inset-2 rounded-full bg-rose-600/30 blur-md pointer-events-none group-hover:bg-rose-500/50" />
              {/* Wax Seal Disc */}
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-rose-700 via-rose-800 to-rose-950 border-2 border-amber-300/40 shadow-[0_4px_16px_rgba(225,29,72,0.6)] flex items-center justify-center relative">
                {/* Irregular wax edge simulation */}
                <div className="absolute inset-0.5 rounded-full border border-rose-500/30" />
                <Heart className="w-7 h-7 text-amber-200 fill-amber-300/40 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]" />
              </div>
            </div>

            <div className="mt-6 flex items-center gap-1.5 text-xs text-rose-300/70 font-medium">
              <Mail className="w-3.5 h-3.5 text-rose-400" />
              <span>Tap wax seal to break & read</span>
            </div>
          </div>
        ) : (
          /* Unfolded Parchment Letter View */
          <div className="relative w-full rounded-2xl bg-gradient-to-b from-[#fdfbf7] via-[#faf6ee] to-[#f4ece1] text-stone-900 p-6 sm:p-9 shadow-[0_20px_50px_rgba(0,0,0,0.9)] border border-amber-200/50 animate-fade-in">
            {/* Parchment vintage paper header motif */}
            <div className="flex items-center justify-between border-b border-amber-900/15 pb-4 mb-5">
              <div className="flex items-center gap-2">
                <Feather className="w-4 h-4 text-amber-800/70" />
                <span className="text-xs uppercase tracking-widest text-amber-900/70 font-semibold font-serif">
                  A Heartfelt Dedication
                </span>
              </div>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="text-xs text-amber-900/70 hover:text-amber-900 font-medium flex items-center gap-1 cursor-pointer py-1 px-2 rounded-md hover:bg-amber-100/60 transition-colors"
                title="Personalize words"
              >
                {isEditing ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Edit3 className="w-3.5 h-3.5" />}
                <span>{isEditing ? 'Done' : 'Personalize'}</span>
              </button>
            </div>

            {/* Preset Selector */}
            {!isEditing && (
              <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1 text-xs">
                <span className="text-amber-900/50 text-[11px] whitespace-nowrap">Style:</span>
                {(['romantic', 'bestie', 'poetic'] as const).map((key) => (
                  <button
                    key={key}
                    onClick={() => {
                      setSelectedTheme(key);
                      setCustomText('');
                    }}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-medium capitalize transition-colors ${
                      selectedTheme === key && !customText
                        ? 'bg-amber-900 text-amber-50 shadow-sm'
                        : 'bg-amber-900/10 text-amber-900 hover:bg-amber-900/20'
                    }`}
                  >
                    {key}
                  </button>
                ))}
              </div>
            )}

            {/* Letter Content */}
            {isEditing ? (
              <div className="space-y-3">
                <textarea
                  value={customText || currentText}
                  onChange={(e) => setCustomText(e.target.value)}
                  rows={8}
                  className="w-full bg-white/70 border border-amber-900/20 rounded-xl p-3 text-stone-900 font-cursive-luxury text-base sm:text-lg leading-relaxed focus:outline-none focus:ring-1 focus:ring-amber-800"
                  placeholder="Write your custom letter here..."
                />
                <button
                  onClick={() => setIsEditing(false)}
                  className="w-full py-2 rounded-xl bg-amber-900 text-amber-100 text-xs font-medium uppercase tracking-wider hover:bg-amber-950 transition-colors"
                >
                  Save Letter
                </button>
              </div>
            ) : (
              <div className="font-cursive-luxury text-base sm:text-lg leading-relaxed text-stone-800 whitespace-pre-line">
                {currentText}
              </div>
            )}

            {/* Golden wax stamp impression in bottom corner */}
            <div className="mt-8 pt-4 border-t border-amber-900/15 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-rose-800/80 flex items-center justify-center text-amber-100 shadow-sm">
                  <Heart className="w-3 h-3 fill-amber-200 text-amber-200" />
                </div>
                <span className="text-xs text-amber-900/60 font-cursive-luxury italic text-sm">
                  Sealed with pure love
                </span>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="text-xs text-amber-900/60 hover:text-amber-950 underline font-medium cursor-pointer"
              >
                Fold Back Up
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
