import React from 'react';
import { Cake, Mail, Image, Gift, Flame } from 'lucide-react';
import { sound } from '../utils/audio';

export const MobileBottomBar: React.FC = () => {
  const scrollTo = (id: string) => {
    sound.playChime(680);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0b0507]/90 backdrop-blur-lg border-t border-rose-500/20 px-2 py-1.5"
    >
      <div className="grid grid-cols-5 items-center max-w-md mx-auto">
        <button
          onClick={() => scrollTo('cake-section')}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-rose-300/70 hover:text-rose-100 active:scale-95 transition-transform"
        >
          <Cake className="w-5 h-5 text-rose-400" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Cake</span>
        </button>

        <button
          onClick={() => scrollTo('letter-section')}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-rose-300/70 hover:text-rose-100 active:scale-95 transition-transform"
        >
          <Mail className="w-5 h-5 text-rose-400" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Letter</span>
        </button>

        <button
          onClick={() => scrollTo('polaroids-section')}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-rose-300/70 hover:text-rose-100 active:scale-95 transition-transform"
        >
          <Image className="w-5 h-5 text-rose-400" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Memories</span>
        </button>

        <button
          onClick={() => scrollTo('cards-section')}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-rose-300/70 hover:text-rose-100 active:scale-95 transition-transform"
        >
          <Gift className="w-5 h-5 text-rose-400" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Gifts</span>
        </button>

        <button
          onClick={() => scrollTo('sparkler-section')}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-rose-300/70 hover:text-rose-100 active:scale-95 transition-transform"
        >
          <Flame className="w-5 h-5 text-rose-400" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Spark</span>
        </button>
      </div>
    </nav>
  );
};
