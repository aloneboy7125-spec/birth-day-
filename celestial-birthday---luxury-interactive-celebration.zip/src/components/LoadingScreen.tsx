import React, { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';

interface LoadingScreenProps {
  onComplete: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    // 2-second loading cycle
    const startTime = performance.now();
    const duration = 2000;

    const interval = setInterval(() => {
      const elapsed = performance.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      if (pct >= 100) {
        clearInterval(interval);
        setIsFading(true);
        setTimeout(() => {
          onComplete();
        }, 500); // 500ms fade transition
      }
    }, 20);

    return () => clearInterval(interval);
  }, [onComplete]);

  const handleSkip = () => {
    setIsFading(true);
    setTimeout(() => {
      onComplete();
    }, 250);
  };

  return (
    <div
      onClick={handleSkip}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0b0507] transition-opacity duration-500 cursor-pointer select-none ${
        isFading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background radial glow */}
      <div className="absolute w-72 h-72 rounded-full bg-rose-600/15 blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute w-44 h-44 rounded-full bg-amber-500/10 blur-2xl pointer-events-none" />

      {/* Pulsing red heart */}
      <div className="relative mb-8 flex items-center justify-center">
        {/* Pulsing outer aura ring */}
        <div className="absolute w-20 h-20 rounded-full bg-rose-500/20 animate-ping duration-1000" />
        
        {/* Heart container with heartbeat scale animation */}
        <div className="relative animate-bounce duration-700">
          <Heart
            className="w-14 h-14 text-rose-500 fill-rose-600 drop-shadow-[0_0_24px_rgba(244,63,94,0.85)] filter"
            strokeWidth={1.5}
          />
        </div>
      </div>

      {/* Loading title text */}
      <div className="text-center px-6">
        <h2 className="text-xs font-semibold tracking-[0.35em] uppercase text-rose-200/90 mb-3">
          LOADING THE EXPERIENCE
        </h2>
        <p className="text-[11px] text-rose-300/40 tracking-wider">
          Crafting a moment made just for you
        </p>
      </div>

      {/* Sleek hairline progress bar */}
      <div className="w-48 h-[2px] bg-rose-950/60 rounded-full mt-7 overflow-hidden relative">
        <div
          className="h-full bg-gradient-to-r from-rose-500 via-pink-400 to-amber-300 transition-all duration-75 ease-out rounded-full shadow-[0_0_12px_rgba(244,63,94,0.9)]"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Tap hint */}
      <div className="absolute bottom-10 text-[10px] tracking-widest uppercase text-rose-400/40">
        Tap to enter
      </div>
    </div>
  );
};
