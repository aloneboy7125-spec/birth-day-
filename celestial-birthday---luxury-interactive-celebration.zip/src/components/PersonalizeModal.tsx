import React, { useState } from 'react';
import { X, Copy, Check, Heart, Sparkles, Share2 } from 'lucide-react';
import { sound } from '../utils/audio';

interface PersonalizeModalProps {
  currentName: string;
  isOpen: boolean;
  onClose: () => void;
  onSaveName: (name: string) => void;
}

export const PersonalizeModal: React.FC<PersonalizeModalProps> = ({
  currentName,
  isOpen,
  onClose,
  onSaveName,
}) => {
  const [nameInput, setNameInput] = useState(currentName);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    sound.playChime(880);
    onSaveName(nameInput.trim());
    onClose();
  };

  const handleCopyLink = () => {
    const url = new URL(window.location.href);
    url.searchParams.set('name', nameInput.trim() || currentName);
    navigator.clipboard.writeText(url.toString());
    sound.playChime(980);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl bg-[#14060c] border border-rose-500/30 p-6 text-rose-100 shadow-[0_20px_60px_rgba(0,0,0,0.95)] animate-fade-in relative"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-rose-400/60 hover:text-rose-100 hover:bg-rose-950/50"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-400/30 flex items-center justify-center text-rose-300">
            <Sparkles className="w-4 h-4 text-amber-300" />
          </div>
          <div>
            <h3 className="text-base font-serif-luxury font-bold text-rose-100">
              Personalize Experience
            </h3>
            <p className="text-[11px] text-rose-300/60">
              Customize the celebration name & create a shareable surprise link
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="bday-name" className="block text-xs text-rose-200/90 font-medium mb-1.5">
              Birthday Star&apos;s Name
            </label>
            <input
              id="bday-name"
              type="text"
              required
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              placeholder="e.g. Sophia, Alexander, My Love..."
              className="w-full bg-black/60 border border-rose-500/40 rounded-xl px-3.5 py-2.5 text-sm text-rose-100 placeholder:text-rose-400/30 focus:outline-none focus:border-rose-400 focus:ring-1 focus:ring-rose-400 font-serif-luxury"
            />
          </div>

          {/* Quick preset suggestions */}
          <div className="flex items-center gap-2 flex-wrap text-xs">
            <span className="text-[11px] text-rose-300/50">Suggestions:</span>
            {['Nabya', 'My Love', 'Princess', 'Bestie', 'Sophia'].map((preset) => (
              <button
                type="button"
                key={preset}
                onClick={() => setNameInput(preset)}
                className="px-2.5 py-1 rounded-lg bg-rose-950/60 border border-rose-500/20 text-rose-200 text-[11px] hover:bg-rose-900/40"
              >
                {preset}
              </button>
            ))}
          </div>

          {/* Action Row */}
          <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
            <button
              type="submit"
              className="min-h-[44px] flex-1 rounded-xl bg-gradient-to-r from-rose-500 to-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider shadow-md hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Heart className="w-4 h-4 fill-stone-950" />
              <span>Apply Name</span>
            </button>

            <button
              type="button"
              onClick={handleCopyLink}
              className="min-h-[44px] px-4 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-200 text-xs font-medium hover:bg-rose-900/60 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4 text-rose-300" />}
              <span>{copied ? 'Link Copied!' : 'Copy Share Link'}</span>
            </button>
          </div>
        </form>

        <p className="mt-4 text-[11px] text-center text-rose-400/50 font-light">
          Tip: Anyone opening the copied link will experience this surprise tailored directly with this name!
        </p>
      </div>
    </div>
  );
};
