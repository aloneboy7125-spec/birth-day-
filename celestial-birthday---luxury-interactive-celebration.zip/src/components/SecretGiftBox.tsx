import React, { useState } from 'react';
import { Gift, Sparkles, Check, Heart, Trophy } from 'lucide-react';
import { sound } from '../utils/audio';
import { fireGlobalBurst } from './BackgroundCanvas';

interface SecretGiftBoxProps {
  recipientName: string;
}

export const SecretGiftBox: React.FC<SecretGiftBoxProps> = ({ recipientName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isClaimed, setIsClaimed] = useState(false);
  const [voucherText, setVoucherText] = useState('1x Unlimited Unconditional Wish granted by the person who sent you this, valid for life.');

  const handleOpenBox = () => {
    if (isOpen) return;
    sound.playGiftOpen();
    sound.playChime(960);
    setIsOpen(true);
    setTimeout(() => {
      sound.playConfettiPop();
      fireGlobalBurst(75);
    }, 450);
  };

  const handleClaim = () => {
    sound.playChime(1100);
    sound.playConfettiPop();
    fireGlobalBurst(50);
    setIsClaimed(true);
  };

  return (
    <section className="relative py-12 px-4 flex flex-col items-center">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="text-center max-w-md mx-auto mb-8">
        <span className="text-xs uppercase tracking-[0.25em] text-rose-300/70 font-medium">
          Surprise Inside
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-rose-100 mt-1 mb-2">
          The Mystery Gift Box
        </h2>
        <p className="text-xs sm:text-sm text-rose-200/60">
          Untie the satin golden ribbon to reveal your exclusive birthday gift
        </p>
      </div>

      <div className="w-full max-w-md flex flex-col items-center">
        {!isOpen ? (
          /* Closed 3D Gift Box */
          <div
            onClick={handleOpenBox}
            className="group cursor-pointer relative w-56 h-56 sm:w-64 sm:h-64 flex flex-col items-center justify-center select-none"
          >
            {/* Pulsing gift halo */}
            <div className="absolute inset-0 rounded-3xl bg-rose-500/15 blur-xl group-hover:bg-rose-500/30 transition-all duration-300 pointer-events-none" />

            {/* Gift Box Lid */}
            <div className="relative w-44 sm:w-48 h-14 rounded-t-2xl bg-gradient-to-r from-rose-800 via-rose-700 to-rose-900 border border-amber-300/40 shadow-xl flex items-center justify-center z-20 group-hover:-translate-y-1 transition-transform">
              {/* Gold Ribbon Horizontal on Lid */}
              <div className="absolute inset-y-0 w-8 bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]" />

              {/* Big Golden Bow */}
              <div className="absolute -top-7 flex items-center justify-center">
                <div className="w-10 h-7 rounded-full bg-gradient-to-tr from-amber-400 to-amber-200 border border-amber-100 shadow-md -rotate-30 -mr-2" />
                <div className="w-5 h-5 rounded-full bg-amber-300 border border-amber-100 z-10 shadow-lg" />
                <div className="w-10 h-7 rounded-full bg-gradient-to-tl from-amber-400 to-amber-200 border border-amber-100 shadow-md rotate-30 -ml-2" />
              </div>
            </div>

            {/* Gift Box Body */}
            <div className="relative w-40 sm:w-44 h-36 rounded-b-2xl bg-gradient-to-b from-[#250912] via-[#1a050c] to-[#0f0307] border border-rose-500/40 shadow-[0_15px_40px_rgba(0,0,0,0.9)] flex items-center justify-center overflow-hidden z-10">
              {/* Vertical Ribbon */}
              <div className="absolute inset-y-0 w-8 bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]" />
              {/* Horizontal Ribbon */}
              <div className="absolute inset-x-0 h-6 bg-gradient-to-b from-amber-300 via-amber-200 to-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]" />

              {/* Tag */}
              <div className="absolute bottom-4 right-3 bg-rose-950/90 border border-amber-300/40 rounded-lg px-2 py-1 rotate-12 shadow-md">
                <span className="text-[10px] text-amber-200 font-cursive-luxury italic font-bold">
                  For {recipientName}
                </span>
              </div>
            </div>

            <div className="mt-6 flex items-center gap-1.5 text-xs text-rose-300/80 font-medium">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin duration-3000" />
              <span>Tap the ribbon to unwrap</span>
            </div>
          </div>
        ) : (
          /* Opened Gift Box & Royal Voucher */
          <div className="w-full rounded-2xl bg-gradient-to-b from-[#1c0811] via-[#130409] to-[#0a0204] border border-amber-300/50 p-6 sm:p-7 shadow-[0_20px_50px_rgba(244,63,94,0.3)] animate-fade-in relative overflow-hidden text-center">
            {/* Top decorative badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/40 text-amber-200 text-xs font-semibold uppercase tracking-widest mb-3">
              <Trophy className="w-3.5 h-3.5 text-amber-300" />
              <span>Golden Birthday Pass</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-serif-luxury font-bold text-rose-100 mb-1">
              Presented to {recipientName}
            </h3>
            <p className="text-xs text-rose-300/60 font-mono tracking-wider mb-5">
              PASS NO. #BDAY-{Math.floor(1000 + Math.random() * 9000)}
            </p>

            {/* Voucher Card Container */}
            <div className="relative rounded-xl bg-gradient-to-r from-amber-100 via-amber-50 to-rose-100 text-stone-900 p-5 shadow-inner border border-amber-300">
              {/* Perforated ticket edges */}
              <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-[#130409]" />
              <div className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-[#130409]" />

              <div className="flex items-center justify-center gap-1 text-rose-700 mb-2">
                <Heart className="w-4 h-4 fill-rose-600" />
                <span className="text-xs font-semibold tracking-wider uppercase">
                  VIP Birthday Privilege
                </span>
                <Heart className="w-4 h-4 fill-rose-600" />
              </div>

              <p className="font-cursive-luxury italic text-stone-800 text-base sm:text-lg leading-snug">
                &quot;{voucherText}&quot;
              </p>

              <div className="mt-4 pt-3 border-t border-stone-300/60 flex items-center justify-between text-[11px] text-stone-500 font-mono">
                <span>Expires: NEVER</span>
                <span>STATUS: {isClaimed ? 'CLAIMED ✨' : 'VALID'}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
              {!isClaimed ? (
                <button
                  onClick={handleClaim}
                  className="min-h-[44px] px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-rose-400 to-pink-500 text-stone-950 font-bold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(251,191,36,0.5)] hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-stone-950" />
                  <span>Claim Golden Pass</span>
                </button>
              ) : (
                <div className="min-h-[44px] px-6 py-2.5 rounded-xl bg-emerald-950/80 border border-emerald-400/40 text-emerald-200 text-xs font-semibold flex items-center justify-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Pass Redeemed! Keep it forever</span>
                </div>
              )}

              <button
                onClick={() => setIsOpen(false)}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-rose-950/40 border border-rose-500/20 text-rose-300/80 text-xs hover:bg-rose-900/40 transition-colors"
              >
                Wrap Box Again
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
