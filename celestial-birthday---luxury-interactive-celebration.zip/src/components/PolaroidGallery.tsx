import React, { useState } from 'react';
import { Camera, Plus, RotateCw, X, Heart, Sparkles } from 'lucide-react';
import { sound } from '../utils/audio';

interface MemoryCard {
  id: string;
  frontTitle: string;
  date: string;
  backNote: string;
  gradient: string;
  icon: string;
  imageSrc?: string;
}

const DEFAULT_MEMORIES: MemoryCard[] = [
  {
    id: '1',
    frontTitle: 'The Starlight Walk',
    date: 'A Golden Evening',
    backNote: 'That night we laughed until our ribs ached under the lamp posts. I remember thinking how lucky the world is to have your bright laughter.',
    gradient: 'from-rose-900 via-pink-950 to-stone-900',
    icon: '✨',
  },
  {
    id: '2',
    frontTitle: 'Coffee & Endless Dreams',
    date: 'Sunday Morning Calm',
    backNote: 'Steaming cups, cold hands, and conversations that stretched across galaxies. Every quiet moment with you feels like home.',
    gradient: 'from-amber-950 via-rose-950 to-neutral-900',
    icon: '☕',
  },
  {
    id: '3',
    frontTitle: 'Unfiltered Joy',
    date: 'Pure Serendipity',
    backNote: 'You didn’t even realize I was watching, but your eyes lit up so brilliantly. Never let anyone dim that radiant sparkle of yours.',
    gradient: 'from-pink-950 via-purple-950 to-stone-900',
    icon: '🌸',
  },
  {
    id: '4',
    frontTitle: 'Sunset Silhouette',
    date: 'Golden Hour Magic',
    backNote: 'The sky was painted in pink and gold, but nothing looked as breathtaking as your smile in that warm light.',
    gradient: 'from-orange-950 via-rose-950 to-stone-950',
    icon: '🌅',
  },
];

export const PolaroidGallery: React.FC = () => {
  const [memories, setMemories] = useState<MemoryCard[]>(DEFAULT_MEMORIES);
  const [flippedIds, setFlippedIds] = useState<Record<string, boolean>>({});
  const [activeModalCard, setActiveModalCard] = useState<MemoryCard | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // Form states for adding custom memory
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newNote, setNewNote] = useState('');
  const [newImage, setNewImage] = useState<string | null>(null);

  const toggleFlip = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playChime(720);
    setFlippedIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setNewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newCard: MemoryCard = {
      id: Date.now().toString(),
      frontTitle: newTitle,
      date: newDate || 'Cherished Memory',
      backNote: newNote || 'A special moment etched into eternity.',
      gradient: 'from-rose-900 via-pink-950 to-black',
      icon: '💖',
      imageSrc: newImage || undefined,
    };

    setMemories([newCard, ...memories]);
    setIsAddingNew(false);
    setNewTitle('');
    setNewDate('');
    setNewNote('');
    setNewImage(null);
    sound.playChime(880);
  };

  return (
    <section className="relative py-12 px-4 max-w-5xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-md mx-auto mb-10">
        <span className="text-xs uppercase tracking-[0.25em] text-rose-300/70 font-medium">
          Frozen In Time
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-rose-100 mt-1 mb-2">
          Memory Polaroids
        </h2>
        <p className="text-xs sm:text-sm text-rose-200/60">
          Tap any polaroid to flip and reveal the secret memory on the back
        </p>
      </div>

      {/* Grid of Polaroids */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 px-2">
        {memories.map((card, idx) => {
          const isFlipped = !!flippedIds[card.id];
          // Alternate subtle vintage tilt
          const tiltClass =
            idx % 4 === 0
              ? '-rotate-2'
              : idx % 4 === 1
              ? 'rotate-1'
              : idx % 4 === 2
              ? '-rotate-1'
              : 'rotate-2';

          return (
            <div
              key={card.id}
              onClick={() => setActiveModalCard(card)}
              className={`group relative cursor-pointer transition-transform duration-300 hover:scale-105 hover:z-20 ${tiltClass}`}
            >
              {/* Vintage Washi Tape Strip on Top */}
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-16 h-6 bg-amber-100/30 backdrop-blur-xs border border-amber-200/20 shadow-xs rotate-[-3deg] z-30 pointer-events-none" />

              {/* Polaroid Paper Frame */}
              <div className="relative bg-[#fcfaf7] text-stone-900 p-3 pt-3.5 pb-5 rounded-md shadow-[0_12px_28px_rgba(0,0,0,0.85)] border border-amber-100/50 flex flex-col justify-between min-h-[300px]">
                {!isFlipped ? (
                  /* Front: Photo / Visual Frame */
                  <div className="flex flex-col h-full">
                    <div className="relative w-full aspect-square rounded-sm overflow-hidden bg-gradient-to-br from-neutral-900 to-black border border-stone-300/40">
                      {card.imageSrc ? (
                        <img
                          src={card.imageSrc}
                          alt={card.frontTitle}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div
                          className={`w-full h-full bg-gradient-to-br ${card.gradient} flex flex-col items-center justify-center p-4 text-center relative overflow-hidden`}
                        >
                          <div className="text-4xl mb-2 drop-shadow-md">{card.icon}</div>
                          <span className="text-[11px] font-cursive-luxury italic text-rose-200/90 tracking-wider">
                            {card.date}
                          </span>
                        </div>
                      )}

                      {/* Flip Trigger Button */}
                      <button
                        onClick={(e) => toggleFlip(card.id, e)}
                        className="absolute bottom-2 right-2 p-1.5 rounded-full bg-black/60 backdrop-blur-md text-white hover:bg-black/90 active:scale-95 transition-all shadow-md cursor-pointer"
                        title="Flip polaroid"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Polaroid Bottom Caption */}
                    <div className="pt-3 px-1 text-center">
                      <h4 className="font-cursive-luxury font-bold text-base text-stone-800 leading-tight">
                        {card.frontTitle}
                      </h4>
                      <p className="text-[10px] text-stone-500 mt-0.5 tracking-wide">
                        {card.date}
                      </p>
                    </div>
                  </div>
                ) : (
                  /* Back: Secret Handwritten Note */
                  <div className="flex flex-col justify-between h-full p-2 bg-[#f8f5ee] rounded-sm">
                    <div>
                      <div className="flex items-center justify-between pb-2 border-b border-stone-300/50">
                        <span className="text-[10px] font-semibold text-rose-800 uppercase tracking-widest">
                          Secret Note
                        </span>
                        <button
                          onClick={(e) => toggleFlip(card.id, e)}
                          className="p-1 text-stone-400 hover:text-stone-800"
                        >
                          <RotateCw className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="mt-3 font-cursive-luxury italic text-stone-700 text-sm leading-relaxed">
                        &quot;{card.backNote}&quot;
                      </p>
                    </div>
                    <div className="pt-2 flex items-center justify-center gap-1 text-[10px] text-stone-400">
                      <Heart className="w-2.5 h-2.5 text-rose-400 fill-rose-400" />
                      <span>Forever in memory</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Custom Memory Button */}
      <div className="mt-8 flex justify-center">
        <button
          onClick={() => setIsAddingNew(true)}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-200 text-xs font-medium hover:bg-rose-900/50 active:scale-95 transition-all flex items-center gap-2 cursor-pointer shadow-md"
        >
          <Plus className="w-4 h-4 text-rose-300" />
          <span>Pin a Custom Memory</span>
        </button>
      </div>

      {/* Add Memory Modal */}
      {isAddingNew && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#14060b] border border-rose-500/30 p-6 text-rose-100 shadow-[0_20px_50px_rgba(0,0,0,0.9)] animate-fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-rose-500/20 mb-4">
              <h3 className="text-base font-serif-luxury font-bold text-rose-100 flex items-center gap-2">
                <Camera className="w-4 h-4 text-rose-400" />
                <span>Create New Memory</span>
              </h3>
              <button
                onClick={() => setIsAddingNew(false)}
                className="p-1 rounded-full text-rose-300/60 hover:text-rose-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddMemory} className="space-y-3.5">
              <div>
                <label className="block text-[11px] text-rose-300/80 mb-1">
                  Memory Title
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Under the Northern Lights"
                  className="w-full bg-black/50 border border-rose-500/30 rounded-xl px-3 py-2 text-xs text-rose-100 focus:outline-none focus:border-rose-400"
                />
              </div>

              <div>
                <label className="block text-[11px] text-rose-300/80 mb-1">
                  Date / Moment
                </label>
                <input
                  type="text"
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  placeholder="e.g. Summer of 2025"
                  className="w-full bg-black/50 border border-rose-500/30 rounded-xl px-3 py-2 text-xs text-rose-100 focus:outline-none focus:border-rose-400"
                />
              </div>

              <div>
                <label className="block text-[11px] text-rose-300/80 mb-1">
                  Secret Note on Back
                </label>
                <textarea
                  rows={3}
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Write a sweet secret memory..."
                  className="w-full bg-black/50 border border-rose-500/30 rounded-xl px-3 py-2 text-xs text-rose-100 focus:outline-none focus:border-rose-400"
                />
              </div>

              <div>
                <label className="block text-[11px] text-rose-300/80 mb-1">
                  Upload Photo (Optional)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="w-full text-xs text-rose-300 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-medium file:bg-rose-900/60 file:text-rose-200 hover:file:bg-rose-800"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingNew(false)}
                  className="flex-1 py-2 rounded-xl bg-rose-950/50 border border-rose-500/20 text-rose-300 text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-pink-500 text-white font-medium text-xs hover:brightness-110 shadow-md"
                >
                  Pin Memory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lightbox Modal */}
      {activeModalCard && (
        <div
          onClick={() => setActiveModalCard(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-[#fcfaf7] text-stone-900 p-4 pb-6 rounded-xl shadow-2xl border border-stone-200 relative animate-fade-in"
          >
            <button
              onClick={() => setActiveModalCard(null)}
              className="absolute -top-10 right-0 text-white/80 hover:text-white p-1"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="w-full aspect-square rounded-md overflow-hidden bg-neutral-900 mb-4">
              {activeModalCard.imageSrc ? (
                <img
                  src={activeModalCard.imageSrc}
                  alt={activeModalCard.frontTitle}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div
                  className={`w-full h-full bg-gradient-to-br ${activeModalCard.gradient} flex flex-col items-center justify-center p-6 text-center`}
                >
                  <div className="text-5xl mb-2">{activeModalCard.icon}</div>
                  <span className="font-cursive-luxury italic text-rose-200 text-sm">
                    {activeModalCard.date}
                  </span>
                </div>
              )}
            </div>

            <div className="text-center px-2">
              <h3 className="font-cursive-luxury font-bold text-2xl text-stone-900">
                {activeModalCard.frontTitle}
              </h3>
              <p className="text-xs text-stone-500 mt-1">{activeModalCard.date}</p>
              <div className="mt-4 pt-3 border-t border-stone-200/80">
                <span className="text-[10px] uppercase tracking-widest text-rose-800 font-semibold block mb-1">
                  The Memory
                </span>
                <p className="font-cursive-luxury italic text-stone-700 text-base leading-relaxed">
                  &quot;{activeModalCard.backNote}&quot;
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
