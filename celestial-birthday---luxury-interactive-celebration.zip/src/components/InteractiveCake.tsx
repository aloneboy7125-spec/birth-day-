import React, { useState } from 'react';
import { Sparkles, RotateCcw, Heart } from 'lucide-react';
import { sound } from '../utils/audio';
import { fireGlobalBurst } from './BackgroundCanvas';

interface InteractiveCakeProps {
  recipientName: string;
}

export const InteractiveCake: React.FC<InteractiveCakeProps> = ({ recipientName }) => {
  const [candles, setCandles] = useState<boolean[]>([true, true, true]);
  const [wishGranted, setWishGranted] = useState(false);
  const [userWishText, setUserWishText] = useState('');
  const [isWishSaved, setIsWishSaved] = useState(false);

  const allBlownOut = candles.every((c) => !c);

  const blowOutCandle = (index: number) => {
    if (!candles[index]) return;
    sound.playCandleBlow();
    const updated = [...candles];
    updated[index] = false;
    setCandles(updated);

    if (updated.every((c) => !c)) {
      handleAllBlown();
    }
  };

  const blowAllCandles = () => {
    if (allBlownOut) return;
    sound.playCandleBlow();
    setCandles([false, false, false]);
    handleAllBlown();
  };

  const handleAllBlown = () => {
    setTimeout(() => {
      sound.playConfettiPop();
      fireGlobalBurst(90, window.innerWidth / 2, window.innerHeight * 0.4);
      setWishGranted(true);
    }, 350);
  };

  const relightCandles = () => {
    sound.playChime(640);
    setCandles([true, true, true]);
    setWishGranted(false);
    setIsWishSaved(false);
  };

  const handleSaveWish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userWishText.trim()) return;
    sound.playChime(880);
    sound.playConfettiPop();
    fireGlobalBurst(40);
    setIsWishSaved(true);
  };

  return (
    <section className="relative py-12 px-4 flex flex-col items-center">
      {/* Subtle section glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="text-center max-w-md mx-auto mb-8">
        <span className="text-xs uppercase tracking-[0.25em] text-rose-300/70 font-medium">
          Make A Sacred Wish
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-rose-100 mt-1 mb-2">
          The Birthday Cake
        </h2>
        <p className="text-xs sm:text-sm text-rose-200/60">
          Tap the glowing candles or make your wish and blow them out together
        </p>
      </div>

      {/* Cake Container */}
      <div className="relative w-64 sm:w-72 h-72 flex flex-col items-center justify-end select-none">
        {/* Cake Plate / Pedestal */}
        <div className="absolute bottom-2 w-64 sm:w-72 h-4 rounded-full bg-gradient-to-r from-amber-200/20 via-rose-200/40 to-amber-200/20 shadow-[0_4px_20px_rgba(244,63,94,0.3)] border border-rose-300/30" />
        <div className="absolute bottom-0 w-36 h-3 rounded-b-xl bg-gradient-to-b from-rose-950/80 to-rose-900/40 border-b border-rose-400/20" />

        {/* Bottom Tier */}
        <div className="relative w-52 sm:w-56 h-20 rounded-2xl bg-gradient-to-b from-[#2a0e17] via-[#200810] to-[#16040a] border border-rose-400/30 shadow-[0_8px_30px_rgba(0,0,0,0.8)] flex flex-col justify-between overflow-hidden">
          {/* Frosting Drips / Scallops */}
          <div className="h-4 w-full flex">
            {[...Array(9)].map((_, i) => (
              <div
                key={i}
                className="flex-1 h-3.5 bg-gradient-to-b from-rose-300/40 to-rose-400/10 rounded-b-full border-b border-rose-300/30"
              />
            ))}
          </div>
          {/* Gold Leaf & Pearl Trims */}
          <div className="flex justify-around items-center px-4 py-1.5 border-t border-rose-400/15">
            {[...Array(7)].map((_, i) => (
              <div key={i} className="w-1.5 h-1.5 rounded-full bg-amber-300/70 shadow-[0_0_6px_#fbbf24]" />
            ))}
          </div>
        </div>

        {/* Top Tier */}
        <div className="relative w-36 sm:w-40 h-16 rounded-2xl -mt-2 bg-gradient-to-b from-[#381320] via-[#2a0c16] to-[#1c060f] border border-rose-400/40 shadow-lg flex flex-col justify-between z-10 overflow-hidden">
          {/* Frosting Swirls */}
          <div className="h-3 w-full flex">
            {[...Array(7)].map((_, i) => (
              <div
                key={i}
                className="flex-1 h-3 bg-gradient-to-b from-rose-200/50 to-rose-300/10 rounded-b-full border-b border-rose-200/30"
              />
            ))}
          </div>
          {/* Central gold heart medallion */}
          <div className="flex justify-center items-center pb-2">
            <Heart className="w-3.5 h-3.5 text-amber-300 fill-amber-300/40 drop-shadow-[0_0_4px_#fbbf24]" />
          </div>
        </div>

        {/* 3 Candles */}
        <div className="absolute top-12 sm:top-14 w-32 flex justify-around items-end z-20">
          {candles.map((isLit, idx) => (
            <div
              key={idx}
              onClick={() => blowOutCandle(idx)}
              className="group cursor-pointer flex flex-col items-center min-w-[44px] min-h-[44px] justify-end"
              title={isLit ? "Tap to blow out" : "Blown out"}
            >
              {/* Flame or Smoke */}
              {isLit ? (
                <div className="relative mb-0.5 flex flex-col items-center">
                  {/* Outer flame aura */}
                  <div className="absolute -top-3 w-6 h-6 rounded-full bg-amber-400/30 blur-[6px] animate-pulse pointer-events-none" />
                  {/* Candle Flame */}
                  <div className="w-2.5 h-5 rounded-t-full rounded-b-md bg-gradient-to-t from-orange-500 via-amber-300 to-yellow-100 animate-flicker shadow-[0_0_12px_#fbbf24]" />
                </div>
              ) : (
                /* Smoke curl */
                <div className="h-6 flex flex-col items-center justify-end pb-1 animate-pulse">
                  <div className="w-1 h-3 rounded-full bg-slate-400/40 blur-[1px] -translate-y-1 transition-transform" />
                  <span className="text-[9px] text-rose-300/50">💨</span>
                </div>
              )}

              {/* Wick */}
              <div className="w-[1.5px] h-2 bg-neutral-900" />

              {/* Candle Body */}
              <div className="w-3 h-10 rounded-t-sm bg-gradient-to-b from-rose-200 via-rose-300 to-rose-400 shadow-[inset_0_1px_3px_rgba(255,255,255,0.6)] border border-rose-300/50 relative overflow-hidden">
                {/* Spiral golden ribbon on candle */}
                <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_40%,rgba(251,191,36,0.5)_50%,transparent_60%)] bg-[length:6px_6px]" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Controls */}
      <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
        {!allBlownOut ? (
          <button
            onClick={blowAllCandles}
            className="min-h-[44px] px-6 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 via-pink-500 to-rose-600 text-white font-medium text-xs tracking-wider uppercase shadow-[0_0_20px_rgba(244,63,94,0.4)] hover:shadow-[0_0_28px_rgba(244,63,94,0.7)] active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-200 animate-spin duration-3000" />
            <span>Blow Out All Candles</span>
          </button>
        ) : (
          <button
            onClick={relightCandles}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-200 font-medium text-xs tracking-wider uppercase shadow-md hover:bg-rose-900/60 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-rose-300" />
            <span>Relight Candles</span>
          </button>
        )}
      </div>

      {/* Wish Granted Celebration Card */}
      {wishGranted && (
        <div className="mt-6 w-full max-w-sm rounded-2xl bg-gradient-to-b from-rose-950/70 to-[#120508]/80 border border-rose-400/30 p-5 shadow-[0_10px_35px_rgba(244,63,94,0.15)] backdrop-blur-md animate-fade-in text-center">
          <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-rose-500/20 border border-rose-400/40 mb-3 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.5)]">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <h3 className="text-base font-serif-luxury font-bold text-rose-100">
            A Wish Whispered to the Cosmos
          </h3>
          <p className="text-xs text-rose-200/80 mt-1.5 leading-relaxed font-cursive-luxury text-sm">
            May every single star shine brighter in honor of your birthday, {recipientName}. All the happiness, love, and wonder you radiate into the world is returning to you tenfold.
          </p>

          {/* Interactive Wish Input Box */}
          {!isWishSaved ? (
            <form onSubmit={handleSaveWish} className="mt-4 pt-3 border-t border-rose-400/15">
              <label htmlFor="user-wish" className="block text-[11px] text-rose-300/80 mb-2">
                Type your secret wish here (it will be sealed in starlight):
              </label>
              <div className="flex gap-2">
                <input
                  id="user-wish"
                  type="text"
                  value={userWishText}
                  onChange={(e) => setUserWishText(e.target.value)}
                  placeholder="e.g. Endless adventures with the ones I love..."
                  className="flex-1 bg-black/40 border border-rose-500/30 rounded-xl px-3 py-2 text-xs text-rose-100 placeholder:text-rose-400/30 focus:outline-none focus:border-rose-400 focus:ring-1 focus:ring-rose-400"
                />
                <button
                  type="submit"
                  className="min-h-[38px] px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-rose-400 text-rose-950 font-semibold text-xs hover:brightness-110 active:scale-95 transition-transform"
                >
                  Seal Wish
                </button>
              </div>
            </form>
          ) : (
            <div className="mt-3 py-2 px-3 rounded-xl bg-rose-500/10 border border-rose-400/20 text-[11px] text-rose-200/90 flex items-center justify-center gap-2">
              <span className="text-amber-300">✨</span>
              <span>Your wish &quot;{userWishText}&quot; is forever locked in the stars!</span>
            </div>
          )}
        </div>
      )}
    </section>
  );
};
