import React from 'react';
import { Volume2, VolumeX, Sparkles } from 'lucide-react';
import { sound } from '../utils/audio';

interface TopNavProps {
  isMusicPlaying: boolean;
  onToggleMusic: () => void;
  onOpenPersonalize: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  isMusicPlaying,
  onToggleMusic,
  onOpenPersonalize,
}) => {
  const scrollTo = (id: string) => {
    sound.playChime(600);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0b0507]/80 backdrop-blur-md border-b border-rose-500/15">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        {/* Zone 1: Single Brand Wordmark */}
        <a
          href="#"
          className="text-lg sm:text-xl font-serif-luxury font-bold tracking-widest text-rose-100 hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          CÉLESTE
        </a>

        {/* Zone 2: Single-line Navigation Links (Desktop) */}
        <nav className="hidden md:flex items-center gap-6 text-xs uppercase tracking-widest font-medium text-rose-200/70">
          <button
            onClick={() => scrollTo('cake-section')}
            className="hover:text-rose-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Cake
          </button>
          <button
            onClick={() => scrollTo('letter-section')}
            className="hover:text-rose-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Letter
          </button>
          <button
            onClick={() => scrollTo('polaroids-section')}
            className="hover:text-rose-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Memories
          </button>
          <button
            onClick={() => scrollTo('cards-section')}
            className="hover:text-rose-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Surprises
          </button>
          <button
            onClick={() => scrollTo('sparkler-section')}
            className="hover:text-rose-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Sparkler
          </button>
        </nav>

        {/* Zone 3: Primary Action & Audio Control */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Quick Audio Equalizer Toggle */}
          <button
            onClick={onToggleMusic}
            aria-label={isMusicPlaying ? 'Mute music' : 'Play serenade'}
            className="min-h-[44px] min-w-[44px] px-2.5 py-1.5 rounded-xl bg-rose-950/40 border border-rose-500/20 text-rose-300 hover:bg-rose-900/40 active:scale-95 transition-all flex items-center gap-1.5 text-xs cursor-pointer"
            title={isMusicPlaying ? 'Serenade playing' : 'Play melody'}
          >
            {isMusicPlaying ? (
              <>
                <Volume2 className="w-4 h-4 text-rose-400" />
                <span className="hidden sm:inline text-[11px] font-mono">SERENADE</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-rose-400/60" />
                <span className="hidden sm:inline text-[11px] font-mono text-rose-400/60">MUTED</span>
              </>
            )}
          </button>

          {/* Primary Action Button */}
          <button
            onClick={onOpenPersonalize}
            className="min-h-[44px] px-3.5 sm:px-4 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-400 text-stone-950 font-semibold text-xs tracking-wider uppercase hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm whitespace-nowrap shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-stone-950" />
            <span>Personalize</span>
          </button>
        </div>
      </div>
    </header>
  );
};
