/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BackgroundCanvas } from './components/BackgroundCanvas';
import { LoadingScreen } from './components/LoadingScreen';
import { TopNav } from './components/TopNav';
import { WelcomeHero } from './components/WelcomeHero';
import { InteractiveCake } from './components/InteractiveCake';
import { WaxSealLetter } from './components/WaxSealLetter';
import { PolaroidGallery } from './components/PolaroidGallery';
import { ScratchSurprises } from './components/ScratchSurprises';
import { SecretGiftBox } from './components/SecretGiftBox';
import { TouchSparklerCanvas } from './components/TouchSparklerCanvas';
import { Footer } from './components/Footer';
import { MobileBottomBar } from './components/MobileBottomBar';
import { PersonalizeModal } from './components/PersonalizeModal';
import { sound } from './utils/audio';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [recipientName, setRecipientName] = useState('Nabya');
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [isPersonalizeOpen, setIsPersonalizeOpen] = useState(false);

  // Parse URL query parameter ?name=... on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const nameParam = params.get('name');
    if (nameParam && nameParam.trim()) {
      setRecipientName(nameParam.trim());
    }
  }, []);

  const handleLoadingComplete = () => {
    setIsLoading(false);
    // Automatically start the gentle serenade if not muted
    sound.startBgm();
    setIsMusicPlaying(true);
  };

  const handleToggleMusic = () => {
    const active = sound.toggleBgm();
    setIsMusicPlaying(active);
  };

  const handleSaveName = (newName: string) => {
    setRecipientName(newName);
    // Update browser URL query string without reloading
    const url = new URL(window.location.href);
    url.searchParams.set('name', newName);
    window.history.replaceState({}, '', url.toString());
  };

  return (
    <div className="min-h-screen bg-[#0b0507] text-rose-50 relative selection:bg-rose-500/30 selection:text-rose-100 overflow-x-hidden">
      {/* 1. Loading Screen */}
      {isLoading && <LoadingScreen onComplete={handleLoadingComplete} />}

      {/* Continuous Animated Background (Confetti & Floating Hearts) */}
      <BackgroundCanvas />

      {/* Top Navigation Bar */}
      <TopNav
        isMusicPlaying={isMusicPlaying}
        onToggleMusic={handleToggleMusic}
        onOpenPersonalize={() => setIsPersonalizeOpen(true)}
      />

      {/* Main Content Layout */}
      <main className="relative z-10 space-y-16 sm:space-y-24">
        {/* Welcome Section */}
        <WelcomeHero
          recipientName={recipientName}
          isMusicPlaying={isMusicPlaying}
          onToggleMusic={handleToggleMusic}
          onOpenPersonalize={() => setIsPersonalizeOpen(true)}
        />

        {/* Section 1: The Birthday Cake & Candle Blow */}
        <div id="cake-section" className="scroll-mt-16">
          <InteractiveCake recipientName={recipientName} />
        </div>

        {/* Section 2: Wax-Sealed Secret Envelope & Letter */}
        <div id="letter-section" className="scroll-mt-16">
          <WaxSealLetter recipientName={recipientName} />
        </div>

        {/* Section 3: Polaroid Memory Gallery */}
        <div id="polaroids-section" className="scroll-mt-16">
          <PolaroidGallery />
        </div>

        {/* Section 4: Golden Surprise Scratch Cards */}
        <div id="cards-section" className="scroll-mt-16">
          <ScratchSurprises />
        </div>

        {/* Section 5: Mystery Gift Box & Golden Pass */}
        <div id="gift-section" className="scroll-mt-16">
          <SecretGiftBox recipientName={recipientName} />
        </div>

        {/* Section 6: Interactive Touch Sparkler */}
        <div id="sparkler-section" className="scroll-mt-16">
          <TouchSparklerCanvas />
        </div>
      </main>

      {/* Footer */}
      <Footer
        recipientName={recipientName}
        onReplayLoading={() => setIsLoading(true)}
      />

      {/* Mobile Ergonomic Bottom Bar */}
      <MobileBottomBar />

      {/* Personalize & Share Link Modal */}
      <PersonalizeModal
        currentName={recipientName}
        isOpen={isPersonalizeOpen}
        onClose={() => setIsPersonalizeOpen(false)}
        onSaveName={handleSaveName}
      />
    </div>
  );
}
